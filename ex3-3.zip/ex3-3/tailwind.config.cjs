module.exports = {
  content: ["./*.{html,js,ts}"],
  darkMode: 'class',
  theme: {
    extend: {},
  },
  plugins: [
  ],
};
